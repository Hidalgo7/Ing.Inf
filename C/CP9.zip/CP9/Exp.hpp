#ifndef EXP_HPP_
#define EXP_HPP_


struct expresionstruct {
  string str ;
  vector<int> trues ;
  vector<int> falses ;
};

#endif /* EXP_HPP_ */
